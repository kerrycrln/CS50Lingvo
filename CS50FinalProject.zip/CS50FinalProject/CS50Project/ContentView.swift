//
//  ContentView.swift
//  p
//
//  Created by Caroline Davudova on 21.12.2022.
//

import SwiftUI
import AVFoundation

struct Item: Identifiable {
    
    let id = UUID()
    let title: String
    let image: String
}

struct ContentView: View {
    
    let items = [
        Item(title: "Home", image: "home"),
        Item(title: "Present",  image: "present"),
        Item(title: "Money",  image: "money"),
        Item(title: "People",  image: "people"),
        Item(title: "Book",  image: "book"),
        Item(title: "Pencil",  image: "pencil"),
        Item(title: "Camera",  image: "camera"),
        Item(title: "Cake",  image: "cake"),
        Item(title: "Snowflake",  image: "snowflake"),
        Item(title: "Flower",  image: "flower"),
    ]
    
    let spacing: CGFloat = 10
    @State private var numberOfRows = 2
    
    var body: some View {

        let columns = Array(
            repeating: GridItem(.flexible(), spacing: spacing),
            count: numberOfRows)
        
        ScrollView {
            
            headerView
            
            LazyVGrid(columns: columns, spacing: spacing) {
                ForEach(items) { item in
                    Button(action:{}) {
                        ItemView(item: item)
                    }
                    .buttonStyle(ItemButtonStyle(cornerRadius: 20))
                }
            }
            .padding(.horizontal)
            .offset(y: -40)
        }
        .background(Color.white)
        .ignoresSafeArea()
    }
    
    var headerView: some View {
        
        VStack{
            NavigationView {
                NavigationLink(destination: VoiceFeature()) {
                    Text("Pronunciation Practice")
                        .font(.system(size: 25))
                        .fontWeight(.heavy)
                        .opacity(0.9)
                        .foregroundColor(.white)
                        .padding(.vertical, 10)
                        .padding(.horizontal, 15)
                        .background(Color.white.opacity(0.3))
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .frame(height: 150)
                        .shadow(color: (Color(red: 0.3, green: 0.6, blue: 1.0)).opacity(0.9), radius: 8, y: 2)
                }
                .frame(height: 280)
                .frame(maxWidth: .infinity)
                .background(Color(red: 0.2, green: 0.45, blue: 0.99))
            }
        }
        .frame(height: 280)
        .frame(maxWidth: .infinity)
        .background(Color(red: 0.2, green: 0.32, blue: 0.99))
    }
}

struct ItemButtonStyle: ButtonStyle {
    let cornerRadius: CGFloat
    
    func makeBody(configuration: Configuration) -> some View {
        ZStack {
            configuration.label
        
            if configuration.isPressed {
                Color.blue.opacity(0.2)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .shadow(color: Color.blue.opacity(0.2), radius: 3, y: 2)
    }
}

struct ItemView: View {
    
    let item: Item
    
    var body: some View {
        
        GeometryReader { reader in
            VStack(spacing: 5) {
                Image(item.image)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 50)
                
                Text(item.title)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .foregroundColor(Color.black.opacity(0.9))
                
            }
            .frame(width: reader.size.width, height: reader.size.height)
            .background(Color.white)
            
        }
        .frame(height: 150)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .shadow(color: Color.blue.opacity(0.2), radius: 3, y: 2)
    
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
