//
//  CS50ProjectApp.swift
//  CS50Project
//
//  Created by Caroline Davudova on 25.12.2022.
//

import SwiftUI

@main
struct CS50ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView()
        }
    }
}
