//
//  VoiceFeature.swift
//  CS50Project
//
//  Created by Caroline Davudova on 27.12.2022.
//

import SwiftUI
import AVFoundation

struct VoiceFeature: View {
    @State private var text : String = ""
    var body: some View {
        let synthesizer = AVSpeechSynthesizer()
        VStack {
            TextField("Enter the word you would like to practice", text: $text)
                .padding()
            
            Button("Practice") {
                let utterance = AVSpeechUtterance(string: "\(text)")
                utterance.voice = AVSpeechSynthesisVoice(language: "en-AU")
                utterance.rate = 0.4
            
                synthesizer.speak(utterance)
            }
        }
        
    }
}

struct VoiceFeature_Previews: PreviewProvider {
    static var previews: some View {
        VoiceFeature()
    }
}
