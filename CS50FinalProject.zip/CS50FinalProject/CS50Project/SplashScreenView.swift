//
//  SplashScreenView.swift
//  CS50Project
//
//  Created by Caroline Davudova on 25.12.2022.
//

import SwiftUI

struct SplashScreenView: View {
    @State private var isActive = false
    @State private var size = 0.8
    @State private var opacity = 0.5
    
    var body: some View {
        if isActive {
            ContentView()
        } else {
            VStack {
                //Background Color
                ZStack(){
                    Color(red: 0.026, green: 0.267, blue: 0.887).ignoresSafeArea()
                    
                    // Background Bubble Effects
                    VStack(){
                        Image("Background Effect")
                            .scaleEffect(1.1)
                            .opacity(0.7)
                            .shadow(radius: 9.0)
                            .blur(radius: 9.0)
                            .blendMode(.luminosity)
                    }
                    
                    // Background Blur
                    VStack(){
                        Color.white
                            .blur(radius: 5)
                            .opacity(0.1)
                            .ignoresSafeArea()
                    }
                    
                    // Cloud IMG
                    VStack(){
                        Image("Cloud")
                            .frame(width: 300, height: 900, alignment: .bottom)
                            .ignoresSafeArea()
                    }
                    
                    // "Let's learn it together"
                    VStack(){
                        Image("Motivation")
                            .blendMode(.screen)
                    }
                    
                    // Logo "CS50 Lingvo"
                    VStack(){
                        Text("CS50 Lingvo").font(.system(size: 50))
                            .fontWeight(.heavy)
                            .foregroundColor(Color.white)
                            .frame(width: 600, height: 680, alignment: .top)
                            .opacity(0.7)
                    }
                    
                    // Button "Let's Do It!"
                    VStack(){
                        Text("LET'S DO IT!")
                            .font(.system(size: 30))
                            .fontWeight(.heavy)
                            .opacity(0.9)
                            .foregroundColor(.white)
                            .padding(.vertical, 10)
                            .padding(.horizontal, 20)
                            .background(Color.white.opacity(0.3))
                            .buttonStyle(.borderedProminent)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .frame(width: 300, height: 250, alignment: .top)
                    }
                    .scaleEffect(size)
                    .opacity(opacity)
                    .onAppear {
                        withAnimation(.easeIn(duration: 2.0)) {
                            self.size = 0.9
                            self.opacity = 1.0
                        }
                    }
                }
                .onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                        self.isActive = true
                    }
                }
            }
        }
    }
}

struct SplashScreenView_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreenView()
    }
}
